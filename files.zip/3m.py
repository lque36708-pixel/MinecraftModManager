#!/usr/bin/env python3
"""
3m - Minecraft Mod Manager via Modrinth API
"""

import sys
import os
import json
import urllib.request
import urllib.parse
import urllib.error
import argparse
import shutil
import re
from pathlib import Path

API_BASE = "https://api.modrinth.com/v2"
USER_AGENT = "3m-cli/1.0 (minecraft-mod-manager)"
CONFIG_FILE = Path.home() / ".config" / "3m" / "profile.json"
CACHE_FILE = Path.home() / ".config" / "3m" / "last_search.json"

# ─── ANSI colors ───────────────────────────────────────────────────────────────
G = "\033[32m"   # green
Y = "\033[33m"   # yellow
C = "\033[36m"   # cyan
B = "\033[34m"   # blue
DIM = "\033[2m"
BOLD = "\033[1m"
R = "\033[0m"    # reset
RED = "\033[31m"

def colored(text, code): return f"{code}{text}{R}"
def err(msg): print(f"{RED}✗ {msg}{R}", file=sys.stderr)
def ok(msg): print(f"{G}✓ {msg}{R}")
def info(msg): print(f"{C}→ {msg}{R}")
def warn(msg): print(f"{Y}! {msg}{R}")

# ─── HTTP helpers ──────────────────────────────────────────────────────────────

def api_get(path, params=None):
    url = f"{API_BASE}{path}"
    if params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        err(f"API error {e.code}: {e.reason} — {path}")
        sys.exit(1)
    except Exception as e:
        err(f"Network error: {e}")
        sys.exit(1)

def download_file(url, dest_path, filename):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            total = int(resp.headers.get("Content-Length", 0))
            downloaded = 0
            with open(dest_path, "wb") as f:
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total:
                        pct = downloaded * 100 // total
                        bar = "█" * (pct // 5) + "░" * (20 - pct // 5)
                        print(f"\r  {bar} {pct:3d}%  {downloaded//1024}KB", end="", flush=True)
        print()
        return True
    except Exception as e:
        err(f"Download failed: {e}")
        if dest_path.exists():
            dest_path.unlink()
        return False

# ─── Profile / config ──────────────────────────────────────────────────────────

def load_profile():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            return json.load(f)
    return None

def save_profile(mc_version, loader):
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        json.dump({"mc_version": mc_version, "loader": loader}, f)

def require_profile():
    p = load_profile()
    if not p:
        err("No profile set. Run: 3m set-profile <mc_version> <loader>")
        err("Example: 3m set-profile 1.21.1 fabric")
        sys.exit(1)
    return p

def save_cache(results):
    CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CACHE_FILE, "w") as f:
        json.dump(results, f)

def load_cache():
    if CACHE_FILE.exists():
        with open(CACHE_FILE) as f:
            return json.load(f)
    return None

# ─── Search ────────────────────────────────────────────────────────────────────

def search_mods(query, profile, limit=10):
    facets = json.dumps([
        [f"versions:{profile['mc_version']}"],
        [f"categories:{profile['loader']}"],
        ["project_type:mod"],
    ])
    data = api_get("/search", {
        "query": query,
        "facets": facets,
        "limit": limit,
    })
    return data.get("hits", [])

def print_results(results, profile):
    if not results:
        warn("Không tìm thấy kết quả nào.")
        return
    print(f"\n{BOLD}Kết quả cho profile: {profile['mc_version']} / {profile['loader']}{R}\n")
    for i, hit in enumerate(results, 1):
        dl = f"{hit.get('downloads', 0):,}"
        follows = hit.get('follows', 0)
        cats = ", ".join(hit.get("categories", [])[:3])
        print(f"  {BOLD}{Y}[{i:2d}]{R} {BOLD}{hit['title']}{R}  {DIM}({hit['slug']}){R}")
        print(f"       {hit.get('description', '')[:80]}")
        print(f"       {G}↓{dl}{R}  {C}♥{follows}{R}  {DIM}{cats}{R}")
        print()

# ─── Get version file ──────────────────────────────────────────────────────────

def get_best_version(slug, profile):
    versions = api_get(f"/project/{slug}/version", {
        "loaders": json.dumps([profile["loader"]]),
        "game_versions": json.dumps([profile["mc_version"]]),
    })
    if not versions:
        return None
    # Ưu tiên release > beta > alpha
    for vtype in ("release", "beta", "alpha"):
        for v in versions:
            if v.get("version_type") == vtype:
                return v
    return versions[0]

def get_primary_file(version):
    files = version.get("files", [])
    for f in files:
        if f.get("primary"):
            return f
    return files[0] if files else None

# ─── Download logic ────────────────────────────────────────────────────────────

def do_download(slug, profile, dest_dir):
    info(f"Đang tìm mod: {slug}")
    version = get_best_version(slug, profile)
    if not version:
        err(f"Không tìm thấy phiên bản phù hợp cho {slug} ({profile['mc_version']} / {profile['loader']})")
        return False

    file_info = get_primary_file(version)
    if not file_info:
        err(f"Không tìm thấy file download cho {slug}")
        return False

    url = file_info["url"]
    filename = file_info["filename"]
    dest = dest_dir / filename

    if dest.exists():
        warn(f"Đã tồn tại: {filename} — bỏ qua")
        return True

    print(f"  {BOLD}{filename}{R}  {DIM}v{version['version_number']}{R}")
    success = download_file(url, dest, filename)
    if success:
        ok(f"Đã tải: {filename}")
    return success

# ─── Commands ──────────────────────────────────────────────────────────────────

def cmd_set_profile(args):
    mc = args.mc_version
    loader = args.loader.lower()
    if loader not in ("fabric", "forge", "quilt", "neoforge"):
        warn(f"Loader '{loader}' không quen thuộc. Tiếp tục...")
    save_profile(mc, loader)
    ok(f"Profile đã đặt: Minecraft {mc} / {loader}")

def cmd_search(args):
    profile = require_profile()
    query = " ".join(args.query)
    info(f"Đang tìm: {query!r}  [{profile['mc_version']} / {profile['loader']}]")
    results = search_mods(query, profile)
    save_cache(results)
    print_results(results, profile)
    if results:
        print(f"{DIM}Dùng 'get -i <số>' hoặc 'show -i <số>' để xem chi tiết / tải.{R}\n")

def cmd_get(args):
    profile = require_profile()
    dest_dir = Path(os.getcwd())

    # get nhiều mod: 3m get sodium, lithium, ...
    if args.names:
        # Ghép lại rồi split theo dấu phẩy
        raw = " ".join(args.names)
        slugs = [s.strip() for s in raw.split(",") if s.strip()]
        for slug in slugs:
            do_download(slug, profile, dest_dir)
        return

    # get theo index
    if args.i is not None:
        cache = load_cache()
        if not cache:
            err("Chưa có kết quả search. Chạy 'search' trước.")
            sys.exit(1)
        idx = args.i - 1
        if idx < 0 or idx >= len(cache):
            err(f"Index {args.i} nằm ngoài kết quả (1–{len(cache)})")
            sys.exit(1)
        slug = cache[idx]["slug"]
        do_download(slug, profile, dest_dir)
        return

    err("Dùng: get <tên> hoặc get -i <số>")
    sys.exit(1)

def cmd_show(args):
    profile = require_profile()

    if args.names:
        raw = " ".join(args.names)
        slug = raw.strip()
        project = api_get(f"/project/{slug}")
    elif args.i is not None:
        cache = load_cache()
        if not cache:
            err("Chưa có kết quả search. Chạy 'search' trước.")
            sys.exit(1)
        idx = args.i - 1
        if idx < 0 or idx >= len(cache):
            err(f"Index {args.i} nằm ngoài kết quả (1–{len(cache)})")
            sys.exit(1)
        slug = cache[idx]["slug"]
        project = api_get(f"/project/{slug}")
    else:
        err("Dùng: show <tên> hoặc show -i <số>")
        sys.exit(1)

    version = get_best_version(project["slug"], profile)

    print(f"\n{BOLD}{project['title']}{R}  {DIM}({project['slug']}){R}")
    print(f"{project.get('description', '')}")
    print(f"\n  {C}Downloads :{R} {project.get('downloads', 0):,}")
    print(f"  {C}Followers :{R} {project.get('followers', 0):,}")
    print(f"  {C}Categories:{R} {', '.join(project.get('categories', []))}")
    print(f"  {C}Loaders   :{R} {', '.join(project.get('loaders', []))}")
    print(f"  {C}MC Vers.  :{R} {', '.join(sorted(project.get('game_versions', []), reverse=True)[:6])}")
    print(f"  {C}License   :{R} {project.get('license', {}).get('id', 'N/A')}")
    print(f"  {C}Source    :{R} {project.get('source_url') or 'N/A'}")
    if version:
        f = get_primary_file(version)
        size_kb = f["size"] // 1024 if f else 0
        print(f"\n  {G}Best version:{R} {version['version_number']}  ({version.get('version_type','?')})")
        print(f"  {G}File         :{R} {f['filename'] if f else 'N/A'}  ({size_kb} KB)")
    print(f"\n  {B}https://modrinth.com/mod/{project['slug']}{R}\n")

def cmd_profile(args):
    p = load_profile()
    if p:
        print(f"Profile hiện tại: {BOLD}{p['mc_version']}{R} / {BOLD}{p['loader']}{R}")
    else:
        warn("Chưa có profile. Chạy: 3m set-profile 1.21.1 fabric")

# ─── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="3m",
        description=f"{BOLD}3m{R} — Minecraft Mod Manager (Modrinth)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ví dụ:
  3m set-profile 1.21.1 fabric
  3m search sodium
  3m get -i 1
  3m get sodium
  3m get sodium, lithium, sodium-extra
  3m show -i 1
  3m show sodium
  3m profile
"""
    )
    sub = parser.add_subparsers(dest="cmd", metavar="<lệnh>")

    # set-profile
    sp = sub.add_parser("set-profile", help="Đặt profile Minecraft (version + loader)")
    sp.add_argument("mc_version", help="Phiên bản Minecraft, ví dụ: 1.21.1")
    sp.add_argument("loader", help="Mod loader: fabric / forge / quilt / neoforge")

    # search
    sp = sub.add_parser("search", help="Tìm mod trên Modrinth")
    sp.add_argument("query", nargs="+", help="Từ khóa tìm kiếm")

    # get
    sp = sub.add_parser("get", help="Tải mod về thư mục hiện tại")
    sp.add_argument("-i", type=int, metavar="INDEX", help="Tải theo index từ kết quả search")
    sp.add_argument("names", nargs="*", help="Tên / slug mod (cách nhau bằng dấu phẩy)")

    # show
    sp = sub.add_parser("show", help="Xem chi tiết mod")
    sp.add_argument("-i", type=int, metavar="INDEX", help="Xem theo index từ kết quả search")
    sp.add_argument("names", nargs="*", help="Tên / slug mod")

    # profile
    sub.add_parser("profile", help="Xem profile hiện tại")

    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(0)

    args = parser.parse_args()

    dispatch = {
        "set-profile": cmd_set_profile,
        "search": cmd_search,
        "get": cmd_get,
        "show": cmd_show,
        "profile": cmd_profile,
    }

    fn = dispatch.get(args.cmd)
    if fn:
        fn(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
